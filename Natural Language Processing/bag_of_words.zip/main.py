# Jerico Luis A. Ungos
# 2021-68060
# CMSC 170 X-1L

# Imports the regex built-in package
import re

# Import the os built-in package
import os

# Imports the tkinter module to be used to create the GUI
# Reference: https://www.geeksforgeeks.org/python-gui-tkinter/
from tkinter import *
from tkinter import font as tfont, filedialog as fd, ttk

# Function that would read and tokenize each word from the input file/s' given messages 
def read_files(input_file):
    # Opens the input file
    # Reference: https://www.digitalocean.com/community/tutorials/python-read-file-open-write-delete-copy
    state_file = open(input_file, 'r')

    # Temporary array that would store the lines of the input file
    temporary_read = []

    # Reads each line of the input file and appends each line as an array to the initial_state array
    for line in state_file:
        temporary_read.append(line.split())
    
    # Closes the input file
    state_file.close()

    # Array that holds the tokenized words from the given messages
    tokenized_read = []

    # Convert the array of arrays into a 1D array
    for sublist in temporary_read:
        for item in sublist:
            tokenized_read.append(item)

    return tokenized_read # Return the array of the tokenized words from the input file

# Function that would clean or remove any non-alphanumeric character in the tokenized words
def clean_tokenized(tokenized_words):
    # Array that holds the cleaned tokens
    clean_tokens = []

    # Loop through each word in the array of tokenized words
    for token in tokenized_words:
        # Regex to remove non-alphanumeric characters
        x = re.split("[^a-z0-9]", token, flags=re.IGNORECASE)
        
        # Checks if the splitted word is an alphanumeric, or contains a non-alphanumeric, or no alphanumeric at all
        if any(word != "" for word in x):
            # If it has at least 1 alphanumeric instance, add the word to the respective array and remove any non-alphanumeric character
            clean_tokens.append(("".join(x)).lower())
    
    return sorted(clean_tokens) # Return the alphabetically sorted array of cleaned tokens

# Function that would every occurrence (or frequency) of the word in the document
def count_words(cleaned_words):
    # Dictionary for the bag of words
    bag_of_words = {}

    # Loop through each word in the array containing the cleaned tokens
    for word in cleaned_words:
        # Checks if the current word is already in the dictionary
        if word in bag_of_words.keys():
            # If so, increment its word count
            bag_of_words[word] = bag_of_words.get(word, 0) + 1
        # Otherwise, add it to the dictory and set its initial word count to 1
        else:
            bag_of_words.update({word: 1})

    return bag_of_words # Return the dictionary of the bag of words

# Function that would write the result total dictionary size, number of words, and resulting dictionary into an output file
def write_output(cleaned_words, result_dict, input_file):
    # Writes the output into the having a dynamic filename of <filename of the input file>-output.txt file
    # Reference: https://www.geeksforgeeks.org/write-a-dictionary-to-a-file-in-python/
    with open(input_file.split('.')[0] + '-output.txt', 'w') as f:
        f.write('Dictionary Size: %s\n' % str(len(result_dict))) 
        f.write('Total Number of Words: %s\n' % str(len(cleaned_words))) 
        for key, value in result_dict.items():
            f.write('%s %s\n' % (key, str(value)))
    
    return

# Function that would select the input file/s 
def new_bag():
    # Opens the filedialog to allow the user to choose an .in input file
    # Reference: https://www.pythontutorial.net/tkinter/tkinter-open-file-dialog/
    filename = fd.askopenfilename(title = "Select an input file or folder", filetypes = (("all files", "*.*"), ("text files", "*.txt")))

    # Checks if the user didn't choose any file
    if (filename == ""):
        return

    # Calls the respective functions that would perform the bag of words algorithm for the selected input file
    clean_words = clean_tokenized(read_files(filename))
    result = count_words(clean_words)
    write_output(clean_words, result, filename)

    # Changes the information displayed in the GUI
    render_gui(clean_words, result)

    return

# Function that would render the GUI
def render_gui(cleaned_words, result_dict):
    # Creates the label that would the total dictionary size
    dict_label = Label(main_window, text = "Dictionary Size: ", width = "20", height = "1", font = tfont.Font(family = "Helvetica", size = 15), anchor="e", justify="right")
    total_dict = Label(main_window, text = str(len(result_dict)), background = "white", borderwidth = 1, relief = "raised", width = "20", height = "1", font = tfont.Font(family = "Helvetica", size = 15))
    
    # Creates the label that would the total number of words
    words_label = Label(main_window, text = "Total Words: ", width = "20", height = "1", font = tfont.Font(family = "Helvetica", size = 15), anchor="e", justify="right")
    total_words = Label(main_window, text = str(len(cleaned_words)), background = "white", borderwidth = 1, relief = "raised", width = "20", height = "1", font = tfont.Font(family = "Helvetica", size = 15))
    
    dict_label.grid(row = 1, column = 0, sticky = W, padx = 5)
    total_dict.grid(row = 1, column = 1, sticky = W, padx = 5)
    words_label.grid(row = 2, column = 0, sticky = W, padx = 5)
    total_words.grid(row = 2, column = 1, sticky = W, padx = 5, pady = 10)

    # Creates the table that would display the resulting dictionary having columns of "word" and "frequency"
    # Reference: https://pythonguides.com/python-tkinter-table-tutorial/
    # Reference: https://www.geeksforgeeks.org/python-tkinter-treeview-scrollbar/
    table_frame = Frame(main_window)

    # Changes the font style and size of the table
    font_style = ttk.Style()
    font_style.configure("Treeview.Heading", font = ("Helvetica", 15))
    font_style.configure("Treeview", font = ("Helvetica", 12))

    # Creates the scrollbar for the table
    table_scroll = Scrollbar(table_frame, orient = VERTICAL)
    table_scroll.pack(side = RIGHT, fill = Y)

    # Creates the table
    table = ttk.Treeview(table_frame, selectmode = "browse", yscrollcommand = table_scroll.set, columns = ("Word", "Frequency"), show = "headings")
    table.pack(padx = (15, 0))

    # Configures the scrollbar to allow scrolling action on the table
    table_scroll.config(command = table.yview)

    # Assign the width and anchor to each column
    table.column("Word", width = 250, anchor = CENTER, minwidth = 100)
    table.column("Frequency", width = 200, anchor = CENTER, minwidth = 100)

    # Assign the headings for each column
    table.heading("Word", text = "Word")
    table.heading("Frequency", text = "Frequency")

    count = 0
    # Insert the data into the table
    for key, value in result_dict.items():
        table.insert("", "end", iid = count, values = (key, value))
        count += 1

    # Display the table
    table_frame.grid(row = 3, column = 0, columnspan = 2, sticky = W, padx = 5)

    return

# Creates the main window
main_window = Tk()
# Sets the title of the main window
main_window.title("Bag of Words")
# Sets the size of the main window
main_window.geometry("500x500")
# Make the window not resizable
main_window.resizable(width = False, height = False)

# Creates a select file label and a select file button
select_file_label = Label(main_window, text = "Select File: ", width = "20", height = "1", font = tfont.Font(family = "Helvetica", size = 15), anchor="e", justify="right")
select_file_button = Button(main_window, command = lambda : new_bag(), text = "Browse...", font = tfont.Font(family = "Helvetica", size = 15))
select_file_label.grid(row = 0, column = 0, sticky = W, padx = 5, pady = 10)
select_file_button.grid(row = 0, column = 1, sticky = W, padx = 5, pady = 10)

# Calls the respective functions that would perform the bag of words algorithm for an initial input file
clean_words = clean_tokenized(read_files("001.txt"))
result = count_words(clean_words)
write_output(clean_words, result, "001.txt")

# Calls the function that would render the GUI using an initial input file
render_gui(clean_words, result)

# Infinite loop that would run the application
# It can be terminated by mouse or keyboard interrupt
main_window.mainloop()