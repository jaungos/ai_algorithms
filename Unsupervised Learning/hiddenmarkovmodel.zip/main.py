# Jerico Luis A. Ungos
# 2021-68060
# CMSC 170 X-1L

# Import the necessary libraries
import copy
import re
import math 

class HiddenMarkovModel:
    def __init__(self, input_file):
        self.input_file = input_file

        self.number_of_strings_to_be_considered = 0
        self.number_of_cases_to_be_considered_for_each_string = 0
        
        self.string_sequences = []
        self.state_values = []
        self.observable_measurement_values = []
        self.cases_to_be_considered_for_each_string = []

        self.state_transition_probabilities = {}
        self.total_probabilities_per_iteration = {}
        self.answer_per_case_per_string = {}

    # Function that would create the keys for the state_transition_probabilities dictionary
    def create_key(self, next_state, current_state):
        return f'P({next_state}|{current_state})'

    # Function for reading the data in the input file
    def read_input_file(self):
        with open(self.input_file, "r") as file_to_read:
            self.number_of_strings_to_be_considered = int(file_to_read.readline())
            
            # Store the string sequences
            for i in range(self.number_of_strings_to_be_considered):
                self.string_sequences.append(file_to_read.readline().strip())

            self.state_values = copy.deepcopy(file_to_read.readline().strip().split())
            self.observable_measurement_values = copy.deepcopy(file_to_read.readline().strip().split())
            
            # Initialize the state_transition_probabilities dictionary
            for state_val in self.state_values:
                self.state_transition_probabilities[state_val] = {}

            # Pair each state with each observable measurement and read their individual probabilities
            for state_val in range(len(self.state_values)):
                # Read the probabilities for each pair value
                probabilities = file_to_read.readline().strip().split()

                for observable_measurement_val in range(len(self.observable_measurement_values)):
                    # Create the key for the state_transition_probabilities dictionary
                    key = self.create_key(self.observable_measurement_values[observable_measurement_val], self.state_values[state_val])
                    
                    # Store the respective probability in the dictionary of (observable measurement|state) pair value probabilities of that respective state
                    self.state_transition_probabilities[self.state_values[state_val]][key] = float(probabilities[observable_measurement_val])

            self.number_of_cases_to_be_considered_for_each_string = int(file_to_read.readline())

            for cases in range(self.number_of_cases_to_be_considered_for_each_string):
                self.cases_to_be_considered_for_each_string.append(file_to_read.readline().strip())

    # Function that would complete the probabilities of the state_transition_probabilities dictionary
    def complete_probabilities(self, current_string_sequence):
        # Match each state with each state
        for current_state in self.state_values:
            for next_state in self.state_values:
                # Create the key for the state_transition_probabilities dictionary
                key = self.create_key(next_state, current_state)

                # Compute for the probability of the current state given the previous state
                count_of_matches = 0
                occurences_of_current_state = 0

                # Scan the string sequence for the pattern of the 'current_state' followed by the 'next_state'
                for character in range(len(current_string_sequence) - 1):
                    # Count the occurences of the current state
                    if current_string_sequence[character] == current_state:
                        occurences_of_current_state += 1

                    if current_string_sequence[character] == current_state and current_string_sequence[character + 1] == next_state:
                        count_of_matches += 1

                # Store the probability of that pair value to the dictionary
                self.state_transition_probabilities[current_state][key] = float(count_of_matches / occurences_of_current_state)

    # Function that would compute for the probability of each case given the string sequence
    def compute_probabilities(self):
        self.read_input_file()

        # For each string sequence
        for string_sequence in self.string_sequences:
            # Complete the probabilities of the state_transition_probabilities dictionary using the current string sequence
            self.complete_probabilities(string_sequence)

            # Reset the total_probabilities_per_iteration dictionary
            self.total_probabilities_per_iteration = {}

            # Initialize the total_probabilities_per_iteration dictionary
            self.total_probabilities_per_iteration[0] = {}
            for state in self.state_values:
                key = f'P({state})'
                if string_sequence[0] == state:
                    self.total_probabilities_per_iteration[0][key] = 1
                else:
                    self.total_probabilities_per_iteration[0][key] = 0

            # Initialize the answer_per_case_per_string dictionary
            self.answer_per_case_per_string[string_sequence] = {}

            for case in self.cases_to_be_considered_for_each_string:
                # Initialize the answer_per_case_per_string dictionary for the current case
                self.answer_per_case_per_string[string_sequence][case] = 1

                # Get the current state and next state
                current_state = case.split()[2]
                next_state = case.split()[0]

                # Get the state and observable measurement by removing the iteration number
                state_needed_by_the_case = re.split("\d", next_state)[0]
                observable_measurement_needed_by_the_case = re.split("\d", current_state)[0]

                # Get the iteration number by removing the state value
                iteration_number = int(re.split("[A-Za-z]", next_state)[1])

                # Check if the needed iteration number is not yet in the total_probabilities_per_iteration dictionary
                if iteration_number not in self.total_probabilities_per_iteration:
                    # Loop through the iterations that are not yet in the total_probabilities_per_iteration dictionary
                    for iteration in range(iteration_number):
                        # Increment the iteration number as 0 is always given
                        iteration += 1

                        # Skip the iteration if it is already in the total_probabilities_per_iteration dictionary
                        if iteration in self.total_probabilities_per_iteration:
                            continue

                        # Initialize the total_probabilities_per_iteration dictionary
                        self.total_probabilities_per_iteration[iteration] = {}

                        # Compute the total probability for each state
                        for first_state in self.state_values:
                            for second_state in self.state_values:
                                # Create the keys for the total_probabilities_per_iteration dictionary
                                current_state_being_computed = f'P({first_state})'
                                next_state_being_computed = f'P({second_state})'

                                # Check if the states are the same
                                if first_state == second_state:
                                    continue

                                # Get the total probability for the current state using 𝑃(𝑆𝑛) = 𝑃(𝑆𝑛|𝑆𝑛−1)𝑃(𝑆𝑛−1) + 𝑃(𝑆𝑛|𝑇𝑛−1)𝑃(𝑇𝑛−1)
                                left_hand_side = self.state_transition_probabilities[first_state][self.create_key(first_state, first_state)] * self.total_probabilities_per_iteration[iteration - 1][current_state_being_computed]
                                right_hand_side = self.state_transition_probabilities[second_state][self.create_key(first_state, second_state)] * self.total_probabilities_per_iteration[iteration - 1][next_state_being_computed]
                                total_probability = left_hand_side + right_hand_side

                                # Store the total probability for the current state
                                self.total_probabilities_per_iteration[iteration][current_state_being_computed] = total_probability

                        # Compute the total probability for each observable measurement
                        for observable_measurement in self.observable_measurement_values:
                            # Initialize the key for the total_probabilities_per_iteration dictionary
                            observable_measurement_being_computed = f'P({observable_measurement})'

                            total_probability = 0

                            for state in self.state_values:
                                current_state_being_computed = f'P({state})'

                                # Get the total probability for the current observable measurement using 𝑃(𝑂𝑛) = 𝑃(𝑂𝑛|𝑆𝑛)𝑃(𝑆𝑛)
                                total_probability += self.state_transition_probabilities[state][self.create_key(observable_measurement, state)] * self.total_probabilities_per_iteration[iteration][current_state_being_computed]

                            # Store the total probability for the current observable measurement
                            self.total_probabilities_per_iteration[iteration][observable_measurement_being_computed] = total_probability

                # Get the total probability for the current case
                numerator = self.state_transition_probabilities[state_needed_by_the_case][self.create_key(observable_measurement_needed_by_the_case, state_needed_by_the_case)] * self.total_probabilities_per_iteration[iteration_number][f'P({state_needed_by_the_case})']
                answer_for_current_case = numerator / self.total_probabilities_per_iteration[iteration_number][f'P({observable_measurement_needed_by_the_case})']

                # Store the answer for the current case
                self.answer_per_case_per_string[string_sequence][case] = answer_for_current_case

            # Write the results to an output file
            self.write_output_file()
    
    # Function that would write the results to an output file
    def write_output_file(self):
        with open("hmm.out", "w") as file_to_write:
            for string_sequence in self.answer_per_case_per_string:
                file_to_write.write(f'{string_sequence}\n')
                for case in self.answer_per_case_per_string[string_sequence]:
                    # Truncate the answer to 4 decimal places without rounding it off
                    # Reference: https://stackoverflow.com/questions/29246455/python-setting-decimal-place-range-without-rounding
                    self.answer_per_case_per_string[string_sequence][case] = math.floor(self.answer_per_case_per_string[string_sequence][case] * 10 ** 4) / 10 ** 4

                    file_to_write.write(f'{case} = {self.answer_per_case_per_string[string_sequence][case]:.4f}\n') 

# Create an instance of the HiddenMarkovModel class
hmm = HiddenMarkovModel("hmm.in")

hmm.compute_probabilities()