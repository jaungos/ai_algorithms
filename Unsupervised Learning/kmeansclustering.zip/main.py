# Jerico Luis A. Ungos
# 2021-68060
# CMSC 170 X-1L

# Import the necessary libraries
import numpy as np # pip install numpy
import csv
import random
import matplotlib.pyplot as plt # pip install matplotlib

class DataPoint:
    def __init__(self, data_point, classification):
        self.data_point = data_point
        self.classification = classification

class KMeansSolver:
    def __init__(self, input_file):
        self.input_file = input_file
        self.k_clusters = 0
        self.index_of_first_attribute_to_use = 0
        self.index_of_second_attribute_to_use = 0
        self.first_attribute = ''
        self.second_attribute = ''

        self.column_headers = []
        self.read_data = {}
        self.training_data = []

        self.current_centroids = []
        self.previous_centroids = []

        self.assigned_data_points = []
    
    # Function for reading the data in the input file
    def read_input_file(self):
        # Read the csv file and store the data in a dictionary of lists where the first row are the keys and the rest are the values
        with open(self.input_file, 'r') as file_to_read:
            csv_file_to_read = csv.reader(file_to_read)

            # Get the first row of the csv file as it will serve as the keys of the training data dictionary
            self.column_headers = next(csv_file_to_read)

            # Initializes the training data dictionary
            for header in self.column_headers:
                self.read_data[header] = []

            # Store the rest of the training data into the dictionary
            for row in csv_file_to_read:
                for index, header in enumerate(self.column_headers):
                    self.read_data[header].append(float(row[index]))

    # Function for prompting the user to input the needed data
    def ask_user_needed_data(self):
        # Prompt the available columns to use for classifying the data into k clusters
        print('\nAvailable attributes to use:')
        for index, header in enumerate(self.column_headers):
            print(f'{index + 1}. {header}')

        # Ask the user for the index of the first attribute to use
        self.index_of_first_attribute_to_use = int(input('\nEnter the index of the first attribute to use: ')) - 1

        while self.index_of_first_attribute_to_use < 0 or self.index_of_first_attribute_to_use >= len(self.column_headers):
            print('\nInvalid Input! The index of the first attribute to use must be between 1 and the number of attributes.\n')
            self.index_of_first_attribute_to_use = int(input('Enter the index of the first attribute to use: ')) - 1

        # Ask the user for the index of the second attribute to use
        self.index_of_second_attribute_to_use = int(input('\nEnter the index of the second attribute to use: ')) - 1

        while self.index_of_first_attribute_to_use == self.index_of_second_attribute_to_use or self.index_of_second_attribute_to_use < 0 or self.index_of_second_attribute_to_use >= len(self.column_headers):
            if self.index_of_first_attribute_to_use == self.index_of_second_attribute_to_use:
                print('\nInvalid Input! The index of the second attribute to use must be different from the first attribute.\n')
            else:
                print('\nInvalid Input! The index of the second attribute to use must be between 1 and the number of attributes.\n')
            
            self.index_of_second_attribute_to_use = int(input('Enter the index of the second attribute to use: ')) - 1
        
        # Ask the user for the number of clusters to use
        self.k_clusters = int(input('\nEnter the number of clusters to use: '))

        # Check if the number of clusters is valid (maximum of 10 clusters)
        while self.k_clusters < 1 or self.k_clusters > 10:
            print('\nInvalid Input! The number of clusters must be between 1 and 10.\n')
            self.k_clusters = int(input('Enter the number of clusters to use: '))

    # Function for initializing the needed data for the algorithm
    def initialize_algorithm(self):
        self.read_input_file()
        self.ask_user_needed_data()

        self.first_attribute = self.column_headers[self.index_of_first_attribute_to_use]
        self.second_attribute = self.column_headers[self.index_of_second_attribute_to_use]

        # Set up the training data to be used for the algorithm
        for index in range(len(self.read_data[self.first_attribute])):
            self.training_data.append(DataPoint(np.array([self.read_data[self.first_attribute][index], self.read_data[self.second_attribute][index]]), -1))

        # Initialize the centroids
        # Reference: https://www.geeksforgeeks.org/unused-variable-in-for-loop-in-python/
        for _ in range(self.k_clusters):
            # Generate a random index from the training data
            random_index = random.randint(0, len(self.training_data) - 1)

            # Check if the generated random index is already used to initialize a centroid
            while any(np.array_equal(self.training_data[random_index].data_point, centroid) for centroid in self.current_centroids):
                random_index = random.randint(0, len(self.training_data) - 1)

            # Add the data point at the random index to the list of centroids
            self.current_centroids.append(self.training_data[random_index].data_point)

            # Initialize the arrays of data point assigned to each centroid
            self.assigned_data_points.append([])

        # Convert the centroids into numpy arrays
        for index, centroid in enumerate(self.current_centroids):
            self.current_centroids[index] = np.array(centroid)

    # Function for performing the K-Means clustering algorithm
    def train(self):
        self.initialize_algorithm()

        # Loop until the centroids no longer change
        while not np.array_equal(self.current_centroids, self.previous_centroids):
            # Clear the previous centroids
            self.previous_centroids.clear()

            # Copy the current centroids to the previous centroids
            for centroid in self.current_centroids:
                self.previous_centroids.append(centroid)

            for data_point in self.training_data:
                # Calculate the euclidean distance of the data point to each centroid
                euclidean_distances = []
                for centroid in self.current_centroids:
                    euclidean_distance = np.linalg.norm(data_point.data_point - centroid)
                    euclidean_distances.append(euclidean_distance)

                # Get the index of the centroid with the minimum euclidean distance
                index_of_closest_centroid = euclidean_distances.index(min(euclidean_distances))

                # Assign the classification of the data point to the classification of the closest centroid
                data_point.classification = index_of_closest_centroid

            # Reassign the centroids and data points assigned to each centroid
            for index, centroid in enumerate(self.current_centroids):
                # Clear the list of data points assigned to the current centroid
                data_points_assigned_to_centroid = []

                for data_point in self.training_data:
                    if data_point.classification == index:
                        # Add the data point to the list of data points assigned to the current centroid
                        data_points_assigned_to_centroid.append(data_point.data_point)

                # Replace the current list of data points assigned to the current centroid with the new list
                self.assigned_data_points[index] = data_points_assigned_to_centroid

                new_centroid = [] # Array for the new centroid

                # Compute the average of the values of each attribute of the data points assigned to the current centroid
                for attribute in range(len(data_points_assigned_to_centroid[0])):
                    average = 0
                    for data_point in data_points_assigned_to_centroid:
                        average += data_point[attribute]
                    average /= len(data_points_assigned_to_centroid)

                    # Add the average to the new centroid
                    new_centroid.append(average)

                # Replace the current centroid with the new centroid
                self.current_centroids[index] = new_centroid

        # Write the result data to a csv file
        self.write_output()

        # Create the scatterplot
        self.create_scatterplot()

    # Function that would write the output data to a csv file
    def write_output(self):
        with open('output.csv', 'w') as file_to_write:
            # Write the final centroids and the data points assigned to each centroid
            for index, centroid in enumerate(self.current_centroids):
                file_to_write.write(f'Centroid: {index} ({centroid[0]}, {centroid[1]})\n')

                for data_point in self.assigned_data_points[index]:
                    file_to_write.write(str(data_point.tolist()) + '\n')

    # Function that would create the scatterplot using the centroids and the data points assigned to each centroid
    # Reference: https://www.geeksforgeeks.org/matplotlib-pyplot-scatter-in-python/
    def create_scatterplot(self):
        # Create a list of colors to use for the data points
        colors = ['red', 'green', 'blue', 'yellow', 'orange', 'purple', 'pink', 'brown', 'black', 'cyan']

        # Create the scatterplot
        for index, centroid in enumerate(self.current_centroids):
            plt.scatter(centroid[0], centroid[1], color = colors[index], marker = 'x', s = 100)

        for index, data_points in enumerate(self.assigned_data_points):
            for data_point in data_points:
                plt.scatter(data_point[0], data_point[1], color = colors[index])
        
        plt.xlabel(self.first_attribute)
        plt.ylabel(self.second_attribute)
        plt.title('K-Means Clustering Scatterplot')
        
        # Save the scatterplot as a png file
        # Reference: https://www.geeksforgeeks.org/how-to-save-a-plot-to-a-file-using-matplotlib/
        plt.savefig('scatterplot.png')
        
        plt.show()

# Create an instance of the K-Means solver class
kmeans_solver = KMeansSolver('Wine.csv')

# Perform the K-Means clustering algorithm
kmeans_solver.train()