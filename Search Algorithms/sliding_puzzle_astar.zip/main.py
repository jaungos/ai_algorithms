# Jerico Luis A. Ungos
# 2021-68060
# CMSC 170 X-1L

# Imports the tkinter module to be used to create the GUI
# Reference: https://www.geeksforgeeks.org/python-gui-tkinter/
from tkinter import *
from tkinter import messagebox as mbox, font as tfont, filedialog as fd

# Class for the game state component
class GameState:
    def __init__(self, stateTiles, zeroTile, parent, stepMade, fValue, pathCost, manhattanValue):
        self.stateTiles = stateTiles
        self.zeroTile = zeroTile
        self.parent = parent 
        self.stepMade = stepMade
        self.fValue = fValue
        self.pathCost = pathCost
        self.manhattanValue = manhattanValue

# Variable used to store the current index of the 0 tile
zero_index = 0
# Variable used to store the current number of moves done by the user
counter = 0

# Read funcction that would extract the initial state of the puzzle from the input file
def puzzle_order(input_file):
    global zero_index

    # The 1D array that would store the initial state of the puzzle
    initial_state = []

    # Opens the input file
    # Reference: https://www.digitalocean.com/community/tutorials/python-read-file-open-write-delete-copy
    state_file = open(input_file, 'r')
    
    # Temporary array that would store the lines of the input file
    temporary_state = []
    
    # Reads each line of the input file and appends each line as an array to the initial_state array
    for line in state_file:
        temporary_state.append(line.split())
    
    # Closes the input file
    state_file.close()
    
    # Convert the array of arrays into a 1D array
    for sublist in temporary_state:
        for item in sublist:
            initial_state.append(item)

    # Loop through the initial state array and find the index of the 0 tile
    for tile in initial_state:
        if (tile == "0"):
            #  Stores the index of the 0 tile
            zero_index = initial_state.index(tile)

    # Returns the initial state of the puzzle
    return initial_state

# Function that would check if the initial state of the puzzle is solvable
def is_solvable(initial_state):
    # Inversion method
    # Variable that would hold the total sum that would determine if the puzzle is solvable or not
    total_sum = 0

    # Nested for loop that would count how many numbers are lower than the current number being compared to
    for item in initial_state:
        # If the current number is 0, don't include it
        if (item == 0):
            continue
        for i in range(initial_state.index(item), len(initial_state)):
            if int(item) > int(initial_state[i]) & int(initial_state[i]) != 0:
                total_sum += 1
    
    # If the total sum is even, the puzzle is solvable
    if (total_sum % 2 == 0):
        return True
    # Otherwise, it is not
    else:
        return False

# Function that would check if the puzzle is already solved
def is_solved(tiles_array):
    # Iterate through the tiles array and check if the current tile is in the correct position where it should be 1-8 followed lastly by 0
    for tile in tiles_array:
        if (tile["text"] == str(0) and tiles_array.index(tile) != 8):
            return False
        elif tile["text"] != str(0) and int(tile["text"]) != tiles_array.index(tile) + 1:
            return False
    
    return True

# Function that would disable all tiles
def disable_all_tiles(tiles_array):
    for tile in tiles_array:
        tile["state"] = "disabled"

# Function that would render all the tiles into the grid
def render_tiles(tiles_array):
    global counter

    for tile in tiles_array:
        if (tile["text"] != "0"):
            tile.grid(row = tiles_array.index(tile) // 3, column = tiles_array.index(tile) % 3, padx = 1, pady = 1)

    # Assign the command to each tile with their respective current index
    for tile in tiles_array:
        # Calling the swap_tiles function through lambda will prevent it from running on call and not repeat every time the tile is clicked
        tile["command"] = lambda clicked_tile = tiles_array.index(tile): swap_tiles(clicked_tile, tiles_array)

    # Calls the function that would check if the puzzle is already solved
    if (is_solved(tiles_array) == True):
        # Once the puzzle is solved, display a message box that would inform the user that the puzzle is solved along with their total moves to complete it
        mbox.showinfo("Congratulations!", "You have solved the puzzle in " + str(counter) + " moves.")
        # Disable all tiles so that the user can't play the game anymore
        disable_all_tiles(tiles_array)

    return

# Function that would enable the tiles adjacent to zero. Otherwise, disable the tiles
def adjacency_checker(tiles_array):
    global zero_index
    # Loop through each tile
    for i in range(9):
        if i == zero_index:
            tiles_array[i]["state"] = "disabled"
        # Check if the tile is adjacent to zero and if so, enables it
        if (i == zero_index - 1 and ((zero_index % 3) != 0)) | (i == zero_index + 1 and ((zero_index % 3) != 2)) | (i == zero_index - 3) | (i == zero_index + 3):
            tiles_array[i]["state"] = "normal"
        # Otherwise, disables it
        else:
            tiles_array[i]["state"] = "disabled"

    return

# Function that would swap the position of the tiles
def swap_tiles(clicked_tile, tiles_array):
    global zero_index
    global counter

    # Uses comma assignment to swap the zero with the number at the index of the tile that was clicked
    tiles_array[clicked_tile], tiles_array[zero_index] = tiles_array[zero_index], tiles_array[clicked_tile]

    # Increment the counter
    counter += 1

    # Update the index which holds 0
    zero_index = clicked_tile

    # Update the state of the tiles
    adjacency_checker(tiles_array)
    
    # Re-render the tiles
    render_tiles(tiles_array)

    return

# Function that would check if the algorithm already reached the goal state
def goalTest(tiles_array):
    # Iterate through the current state's config and check if the current tile is in the correct position where it should be 1-8 followed lastly by 0
    for tile in tiles_array:
        # If at least 1 is not in its proper index, it would immediately return False to signify it is not yet the Goal State
        if (tile == str(0) and tiles_array.index(tile) != 8):
            return False
        elif tile != str(0) and int(tile) != tiles_array.index(tile) + 1:
            return False
    
    # Otherwise, return True as everything are in the right place
    return True

# Function that would check the possible actions the current state could perform
def Actions(currentState):
    actionsSet = []
    
    # Conditoonal statements to check what actions the current state can do
    if currentState.zeroTile // 3 > 0 : # Check if the current state can make upward swap
        actionsSet.append("U")
    if currentState.zeroTile % 3 < 2: # Check if the current state can make rightward swap
        actionsSet.append("R")
    if currentState.zeroTile // 3 < 2: # Check if the current state can make downward swap
        actionsSet.append("D")
    if currentState.zeroTile % 3 > 0: # Check if the current state can make leftward swap
        actionsSet.append("L")

    return actionsSet

# Function that would perform the passed action a on the passed current state
def Result(currentState, a):
    # DUplicates the state tile configuration to avoid any modification on the original configuration
    temp = currentState.stateTiles.copy()
    
    # Checks which action is passed and performs the respective swap on the passed current state
    # Also, stores the updated index of zero into a variable to be used in the instatiation of a new game state
    if a == "U":
        temp[currentState.zeroTile], temp[currentState.zeroTile-3] = temp[currentState.zeroTile-3], temp[currentState.zeroTile]
        new_index = currentState.zeroTile - 3
    elif a == "R":
        temp[currentState.zeroTile], temp[currentState.zeroTile+1] = temp[currentState.zeroTile+1], temp[currentState.zeroTile]
        new_index = currentState.zeroTile + 1
    elif a == "D":
        temp[currentState.zeroTile], temp[currentState.zeroTile+3] = temp[currentState.zeroTile+3], temp[currentState.zeroTile]
        new_index = currentState.zeroTile + 3
    elif a == "L":
        temp[currentState.zeroTile], temp[currentState.zeroTile-1] = temp[currentState.zeroTile-1], temp[currentState.zeroTile]
        new_index = currentState.zeroTile - 1

    # Returns a new game state with the passed current as its new parent
    return GameState(temp, new_index, currentState, a, -1, currentState.pathCost+1, -1)
    
# Function that would perform the BFS algorithm
def BFSearch(game_state):
    # Initializes the needed arrays
    frontier = [game_state] # Stores the states that can be explored
    explored = [] # Stores the states that have been already explored
    
    # Loops continuously until the frontier becomes empty or the goal state has been reached
    while (len(frontier) != 0):
        currentState = frontier.pop(0) # Dequeue the first inserted state
        explored.append(currentState.stateTiles)
        # Checks if the current state is already the goal state
        if (goalTest(currentState.stateTiles)):
            # If so, prints the states explored and the total number of states explored
            for state in explored:
                print(state)
            print("Total Explored States: ", len(explored))
            # Returns the current state as it is the last state since it already matches the goal state
            return currentState
        # Otherwise, performs all possible action that could be made in the current state
        else:
            for a in Actions(currentState):
                result_state = Result(currentState, a)
                # Checks if the resulting game state has already been added to the states to be explored or states already explored
                # Reference: https://docs.python.org/3/library/functions.html#any
                if ((result_state.stateTiles not in explored) and (any(state.stateTiles == result_state.stateTiles for state in frontier) == False)):
                    # If not, add it to the states to be explored
                    frontier.append(result_state)

# Function that would perform the DFS algorithm
def DFSearch(game_state):
    # Initializes the needed arrays
    frontier = [game_state] # Stores the states that can be explored
    explored = [] # Stores the states that have been already explored

    # Loops continuously until the frontier becomes empty or the goal state has been reached
    while (len(frontier) != 0):
        currentState = frontier.pop() # Pops the last inserted state
        explored.append(currentState.stateTiles)
        # Checks if the current state is already the goal state
        if (goalTest(currentState.stateTiles)):
            # If so, prints the states explored and the total number of states explored
            for state in explored:
                print(state)
            print("Total Explored States: ", len(explored))
            # Returns the current state as it is the last state since it already matches the goal state
            return currentState
        # Otherwise, performs all possible action that could be made in the current state
        else:
            for a in Actions(currentState):
                result_state = Result(currentState, a)
                # Checks if the resulting game state has already been added to the states to be explored or states already explored
                # Reeference: https://docs.python.org/3/library/functions.html#any
                if ((result_state.stateTiles not in explored) and (any(state.stateTiles == result_state.stateTiles for state in frontier) == False)):
                    # If not, add it to the states to be explored
                    frontier.append(result_state)

# Function that would perform the A* Search algorithm
def Astar(game_state):
    # Initializes the needed arrays
    frontier = [game_state] # Stores the states that can be explored
    explored = [] # Stores the states that have been already explored

    # Loops continuously until the frontier becomes empty or the goal state has been reached
    while (len(frontier) != 0):
        bestNode = removeMinF(frontier) # Gets the (first) state that has the lowest heuristic value
        explored.append(bestNode.stateTiles)
        # Checks if the current state is already the goal state
        if (goalTest(bestNode.stateTiles)):
            # If so, prints the states explored and the total number of states explored
            for state in explored:
                print(state)
            print("Total Explored States: ", len(explored))
            # Returns the current state as it is the last state since it already matches the goal state
            return bestNode
        # Otherwise, performs all possible action that could be made in the current state
        else:
            for a in Actions(bestNode):
                result_state = Result(bestNode, a)
                # Checks if either the resulting game state has already been added to the states to be explored or states already explored
                # Reference: https://docs.python.org/3/library/functions.html#any
                if ((result_state.stateTiles not in explored) and (any(state.stateTiles == result_state.stateTiles for state in frontier) == False)):
                    frontier.append(result_state)
                
                # Or if the resulting game state has already a duplicate in the frontier and has a path cost greater or equal to the duplicate
                elif (any(state.stateTiles == result_state.stateTiles for state in frontier)):
                    for state in frontier:
                        if (result_state.stateTiles == state.stateTiles and result_state.pathCost < state.pathCost):
                            frontier.append(result_state)
                            break
    return

# Function that would compute for the manhattan distance of the passed game state's tile configuration
def compute_Manhattan(current_state):
    total_distance = 0

    # Nested for loop that would count how many steps it is from its proper place
    for item in current_state:
        # If the current number is 0, don't include it
        if (item == str(0)):
            continue
        # Checks if the current tile is in the proper place already
        if (item != str(0) and int(item) == current_state.index(item) + 1):
            continue
        # Otherwise, count the distance need to make in order to reach right place
        else:
            total_distance += abs((current_state.index(item)//3) - ((int(item)-1)//3)) + abs((current_state.index(item)%3) - ((int(item)-1)%3))

    # Returns the manhattan distance
    return total_distance

# Function that would find the game state that would have the smallest f value from the passed array of game states
def removeMinF(open_list):
    # Array that would hold the heuristic value for each state in the open list
    all_F = []

    # Computes the heuristic value for each state in the open list
    for state in open_list:
        if (state.fValue == -1):
            state.manhattanValue = compute_Manhattan(state.stateTiles)
            state.fValue =  state.pathCost + state.manhattanValue
        
        all_F.append(state.fValue)

    # Gets the smallest heuristic value and its index
    min_f = min(all_F)
    min_f_index = all_F.index(min_f)

    # Remove the state in the open list that matches the smallest heuristic value
    # Returns that state as a return value
    return open_list.pop(min_f_index)

# Function that would trace the path from the goal state to the root state
def trace_root(goal_state):
    traversal = []

    # Loop that would continuously add the connecting path from the goal state to its root parent
    while (goal_state.parent != None):
        traversal.append(goal_state)
        # Updates the current state to its parent state
        goal_state = goal_state.parent

    # Reverse the array of path taken to serve as the solution to the game
    # This would make the array start with the parent state and ends with the goal state
    proper_traverse = traversal[::-1]

    return proper_traverse

# Function that would write the solution path into an output file
def write_solution(solution_array):
    # Opens/Creates the output file with a 'write' mode 
    state_file = open('puzzle.out', 'w')
    
    # Write the solution into the output file
    state_file.write(solution_array)

    # Closes the output file
    state_file.close()

# Function that would display the next action of the solution
def display_next(solution_array, tiles_array, btn):
    global zero_index, counter

    # Loop through the initial state array and find the index of the 0 tile
    # Also, resets all the colors of the tile back to the default to highlight the next step
    for tile in tiles_array:
        tile["bg"] = "#f9eae1"
        if (tile["text"] == "0"):
            #  Stores the index of the 0 tile
            zero_index = tiles_array.index(tile)

    # Gets the first action in the array containing the solution
    currentStep = solution_array.pop(0)

    # Checks what action would be made and perform the respective action into the current state
    # Also, changes the color of the tile needed to be pressed
    if currentStep == "U":
        tiles_array[zero_index-3]["bg"] = "#87CEEB"
        tiles_array[zero_index], tiles_array[zero_index-3] = tiles_array[zero_index-3], tiles_array[zero_index]
    elif currentStep == "R":
        tiles_array[zero_index+1]["bg"] = "#87CEEB"
        tiles_array[zero_index], tiles_array[zero_index+1] = tiles_array[zero_index+1], tiles_array[zero_index]
    elif currentStep == "D":
        tiles_array[zero_index+3]["bg"] = "#87CEEB"
        tiles_array[zero_index], tiles_array[zero_index+3] = tiles_array[zero_index+3], tiles_array[zero_index]
    elif currentStep == "L":
        tiles_array[zero_index-1]["bg"] = "#87CEEB"
        tiles_array[zero_index], tiles_array[zero_index-1] = tiles_array[zero_index-1], tiles_array[zero_index]

    # Rerender the tiles based on the new array of tiles
    for tile in tiles_array:
        if (tile["text"] != "0"):
            tile.grid(row = tiles_array.index(tile) // 3, column = tiles_array.index(tile) % 3, padx = 1, pady = 1)
    
    # Checks if all the solution in the array has been exhausted
    if len(solution_array) == 0:
        # If so, disable the 'next' button and prompt the total path cost of the solution
        btn["state"] = DISABLED
        mbox.showinfo("End of Solution!", "This solution would cost " + str(counter) + " moves.")

    return

# Function that displays the solution using the selected brute force search algorithm 
def solve_button(dropAlgo):
    global counter
    # Removes the current tiles in the grid
    for i in range(9):
        tiles[i].grid_forget()
    
    # Recreate the 8 tiles for the game
    for i in range(9):
        tiles.pop(0)
        tiles.append(Button(main_window, text = initial_state.stateTiles[i], width = "10", height = "5", state = DISABLED, bg = "#F9EAE1", font = tfont.Font(family = "Helvetica", size = 25)))

    # Render the recreated initial state of the tiles
    for tile in tiles:
        if (tile["text"] != "0"):
            tile.grid(row = tiles.index(tile) // 3, column = tiles.index(tile) % 3, padx = 1, pady = 1)
    
    # Prevents all the tiles from being pressed to avoid interrupting the displaying of solution
    disable_all_tiles(tiles)
    
    # Checks what algorithm to perform and get the solution array of sets from the respective function call
    if dropAlgo.get() == "BFS":
        solution = trace_root(BFSearch(initial_state))
    elif dropAlgo.get() == "DFS":
        solution = trace_root(DFSearch(initial_state))
    elif dropAlgo.get() == "A* Search":
        solution = trace_root(Astar(initial_state))

    # Stores the steps made from the initial state up to reach the goal state
    steps_array = []
    for sol in solution:
        steps_array.append(sol.stepMade)

    counter = len(steps_array)

    # Combine the elements of the array into a single string
    sol_array = " ".join(steps_array)

    # Write the solution string into the output file
    write_solution(sol_array)

    # Prevent drop button, solution button, and new puzzle button from being pressend anymore
    solution_button["state"] = DISABLED
    drop.config(state = DISABLED)
    new_puzzle_button["state"] = DISABLED

    # Label for the 'Solution: ' header
    solution_label = Label(main_window, text = "Solution: ", font = tfont.Font(family = "Helvetica", size = 15))
    solution_label.grid(row = 0, column = 3, padx = 50, pady = 1)

    # Label for the actual solution itself
    sol_label = Label(main_window, text = sol_array, font = tfont.Font(family = "Helvetica", size = 20))
    sol_label.grid(row = 1, column = 3, padx = 50, pady = 1)

    # Button used by the user to proceed to the next solution
    next_button = Button(main_window, command = lambda solution_array = steps_array, new_tiles = tiles: display_next(solution_array, new_tiles, next_button) , text = "Next", width = "10", height = "1", font = tfont.Font(family = "Helvetica", size = 15))
    next_button.grid(row = 2, column = 3, padx = 50, pady = 1)

# Function that reads the input file and stores the initial state of the puzzle
def new_puzzle():
    global counter, initial_state

    # Opens the filedialog to allow the user to choose an .in input file
    # Reference: https://www.pythontutorial.net/tkinter/tkinter-open-file-dialog/
    filename = fd.askopenfilename(title = "Select an input file", filetypes = (("input files", "*.in"), ("text files", "*.txt")))

    # Checks if the user didn't choose any file
    if (filename == ""):
        return

    # Replace the current state of the puzzle with the a game state containing the new configuration from the input file
    initial_state = GameState(puzzle_order(filename), zero_index, None, "N/A", -1, 0, -1)
    
    # Removes the current tiles in the grid
    for i in range(9):
        tiles[i].grid_forget()
    
    # Replaces the configuration of the tiles with the new configuration 
    for i in range(9):
        tiles.pop(0)
        tiles.append(Button(main_window, text = initial_state.stateTiles[i], width = "10", height = "5", state = DISABLED, bg = "#F9EAE1", font = tfont.Font(family = "Helvetica", size = 25)))

    # Reset the counter to 0
    counter = 0

    # Call the function that would enable the tiles adjacent to zero. Otherwise, disable it
    adjacency_checker(tiles)

    # Call the function that would render the tiles on the main window
    render_tiles(tiles)

# Creates the main window
main_window = Tk()
# Sets the title of the main window
main_window.title("8-Puzzle Game")
# Make the window not resizable and just make it big enough to fit all contents
main_window.resizable(width = False, height = False)

# Array of possible brute force search algorithms to choose from
solution_option = ["BFS", "DFS", "A* Search"]
# Initialize the dropdown menu and set the initial choice to "BFS"
drop_menu = StringVar(value = solution_option[0])
# Create the dropdown options
drop = OptionMenu(main_window, drop_menu, *solution_option, command = lambda selected = drop_menu.get(): print(selected))
# Make the width of the dropdown menu constant
drop.config(width = "10", height = "1", font = tfont.Font(family = "Helvetica", size = 15))
# Render in the main window
drop.grid(row = 3, column = 1, padx = 1, pady = 1)

# Create the "Solution" button
solution_button = Button(main_window, command = lambda dropAlgo = drop_menu: solve_button(dropAlgo), text = "Solution", width = "10", height = "1", font = tfont.Font(family = "Helvetica", size = 15))
solution_button.grid(row = 3, column = 2, padx = 1, pady = 10)

# Create the "New Puzzle" button
new_puzzle_button = Button(main_window, command = lambda : new_puzzle(), text = "New Puzzle", width = "10", height = "1", font = tfont.Font(family = "Helvetica", size = 15))
new_puzzle_button.grid(row = 4, column = 1, padx = 1, pady = 10)

# Initializes the initial state of the game using the config from puzzle.in
initial_state = GameState(puzzle_order('puzzle.in'), zero_index, None, "N/A", -1, 0, -1)

# Creates the 8 buttons that will serve as the tiles for the game and store it an array
tiles = []
for i in range(9):
    tiles.append(Button(main_window, text = initial_state.stateTiles[i], width = "10", height = "5", state = DISABLED, bg = "#F9EAE1", font = tfont.Font(family = "Helvetica", size = 25)))

# Call the function that would enable the tiles adjacent to zero. Otherwise, disable it
adjacency_checker(tiles)

# Call the function that would render the tiles on the main window
render_tiles(tiles)

# Call the function that would check if the initial state of the puzzle is solvable before allowing the user to play the game
if (is_solvable(initial_state.stateTiles) == False):
    # If the puzzle is not solvable, display a message box that would inform the user that the puzzle is not solvable
    # Also, ask the user if they want to close the entire program
    # Referencce: https://www.pythontutorial.net/tkinter/tkinter-askokcancel/
    decision = mbox.askokcancel(title = "", message = "The puzzle is not solvable. Do you want to close the entire program?", icon = "warning")

    # If the user clicked "ok", close the entire program
    if decision:
        main_window.destroy()
    # Otherwise, show the board but won't allow the user to play the game by making all the tiles not clickable
    else:
        disable_all_tiles(tiles)
        solution_button["state"] = DISABLED
        drop.config(state = DISABLED)

# Infinite loop that would run the application
# It can be terminated by mouse or keyboard interrupt
main_window.mainloop()
