# Jerico Luis A. Ungos
# 2021-68060
# CMSC 170 X-1L

# Import the numpy package for creating vectors and performing vector operations
import numpy as np

class KNNSolver:
    def __init__(self, input_dir):
        self.input_dir = input_dir
        self.training_data_dir = 'diabetes.csv'
        
        self.kValue = 0
        
        self.training_data = []
        self.classifications = []
        
        self.input_data = []
        
        self.result = []
        self.euclidean_distances = []
        self.k_nearest_neighbors = []
        self.count_per_classification = {}
        self.tied_classifications = []
        self.output_data = []
    
    # Function for reading the data to be classified in the input file
    def read_input_data(self):
        with open(self.input_dir, 'r') as input_file:
            for data_line in input_file:
                # Remove the newline character and split the data into a list of strings
                data_line = data_line.strip().split(',')
                
                # Convert the list of strings into a list of floats
                data_line = [float(data) for data in data_line]
                
                # Convert the list of integers into a numpy array
                data_vector = np.array(data_line)
                
                self.input_data.append(data_vector)
                
    # Function for reading the data in the training data file
    def train(self):
        with open(self.training_data_dir, 'r') as training_file:
            for data_line in training_file:
                # Remove the newline character and split the data into a list of strings
                data_line = data_line.strip().split(',')
                
                # Convert the list of strings into a list of floats
                data_line = [float(data) for data in data_line]
                
                # Convert the list of integers into a numpy array
                data_vector = np.array(data_line)
                
                self.training_data.append(data_vector)
            
        # Count the number of unique values in the last element of each data vector
        for data in self.training_data:
            if data[-1] not in self.classifications:
                self.classifications.append(data[-1])
                
    # Function for performing the KNN algorithm to classify the input data
    def classify(self, kValue):
        self.kValue = kValue
        
        # Read the input data from the input file
        self.read_input_data()
        
        # For each data vector in the input data
        for input_vector in self.input_data:
            # Copy the input vector to a result list
            self.result = input_vector.tolist().copy()
            
            # Compute the Euclidean distance between the input vector and each data vector in the training data
            for training_vector in self.training_data:
                # Compute the Euclidean distance between the input vector and the training vector up until before the last element as it is for the classification
                euclidean_distance = np.linalg.norm(input_vector - training_vector[:-1])
                
                # Append the Euclidean distance along with the classification of the current training vector to the list of Euclidean distances
                self.euclidean_distances.append((euclidean_distance, training_vector[-1]))
            
            # Sort the list of Euclidean distances in ascending order
            self.euclidean_distances.sort()
            
            # Get the k nearest neighbors
            self.k_nearest_neighbors = self.euclidean_distances[:self.kValue]
            
            # Create a dictionary for counting the number of occurrences of each classification among the k nearest neighbors
            for classification in self.classifications:
                self.count_per_classification[classification] = 0
                
            # Count the number of occurrences of each classification among the k nearest neighbors
            for neighbor in self.k_nearest_neighbors:
                self.count_per_classification[neighbor[1]] += 1
                
            # Check if there are any ties in the classification of the k nearest neighbors
            for classification in self.classifications:
                if self.count_per_classification[classification] == max(self.count_per_classification.values()):
                    # Add the classification to the list of tied classifications
                    self.tied_classifications.append(classification)                    
            
            # If there are ties
            if len(self.tied_classifications) > 1:
                # Check the lowest Euclidean distance among the tied classifications
                for neighbor in self.k_nearest_neighbors:
                    if neighbor[1] in self.tied_classifications:
                        # Append the classification to the output vector
                        self.result.append(neighbor[1])
                        break
            else:
                # Otherwise, append the most common classification among the k nearest neighbors to the output vector
                self.result.append(max(self.count_per_classification, key = self.count_per_classification.get)) 
            
            # Duplicate the result list to be appended to the output data
            duplicateOfResult = self.result.copy()
            self.output_data.append(duplicateOfResult)
            
            # Clear the result list for the next input vector
            self.result.clear()
            
            # Clear the list of Euclidean distances for the next input vector
            self.euclidean_distances.clear()
            
            # Clear the list of k nearest neighbors for the next input vector
            self.k_nearest_neighbors.clear()
            
            # Clear the dictionary of counts per classification for the next input vector
            self.count_per_classification.clear()
            
            # Clear the list of tied classifications for the next input vector
            self.tied_classifications.clear()
            
        # Print the output data
        for data in self.output_data:
            print(data)
            
        # Write the output data to the output file
        with open('output.txt', 'w') as output_file:
            for data in self.output_data:
                # Write the data to the output file by removing the brackets and spaces
                output_file.write(str(data).strip('[]').replace(' ', '') + '\n')

# Create an instance of the KNNSolver class
KNNsolver = KNNSolver('input.in')

# Train the model using the training data
KNNsolver.train()

# Request the user to input the value of k for the KNN algorithm
kValue = int(input('Enter the value of k: '))

# Classify the input data
KNNsolver.classify(kValue)