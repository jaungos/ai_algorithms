# Jerico Luis A. Ungos
# 2021-68060
# CMSC 170 X-1L

# Import the numpy package for creating vectors and performing vector operations
import numpy as np

# Import the PrettyTable package for displaying the table
# Install the PrettyTable package using the command: pip install PrettyTable
from prettytable import PrettyTable


class Perceptron:
    def __init__(self, input_dir):
        self.input_dir = input_dir
        
        self.learning_rate = 0.0
        self.threshold = 0.0
        self.bias = 0.0

        self.training_data = []
        self.weights = []

        self.num_coordinates = 0
        self.currentIteration = 1

        self.column_headers = []
        self.all_weights = []

        self.hasConverge = False

    # Function that would read the input file
    def read_input(self):
        state_file = open(self.input_dir, 'r')
        # Read the first and store it as the learning rate
        self.learning_rate = float(state_file.readline())

        # Read the second line and store it as the threshold
        self.threshold = float(state_file.readline())

        # Read the third line and store it as the bias
        self.bias = float(state_file.readline())

        # Read the remaining lines as the training data
        for line in state_file:
            # Store each line as a vector
            # Reference: https://www.geeksforgeeks.org/how-to-create-a-vector-in-python-using-numpy/
            
            # Remove the newline character at the end of the line
            line = line.strip('\n')

            # Split the line into a list of strings
            line = line.split(' ')

            # Convert the list of strings into a list of integers
            line = [int(i) for i in line]

            # Convert the list of integers into a numpy array
            vector = np.array(line)

            # Append the vector to the training data
            self.training_data.append(vector)

        # Close the input file
        state_file.close()

        return

    # Function that would initialize the needed data for the first iteration
    def initializePerceptron(self):
        # Call the function to read the data from an input file
        self.read_input()

        # Determine the number of coordinates
        self.num_coordinates = len(self.training_data[0]) - 1

        # Initialize the column headers
        for i in range(self.num_coordinates):
            self.column_headers.append(f'x{i}')

        self.column_headers.append('b')

        for i in range(self.num_coordinates):
            self.column_headers.append(f'w{i}')

        last_column_headers = ['wb', 'a', 'y', 'z']
        self.column_headers.extend(last_column_headers)

        # Initialize the weights
        self.weights = np.zeros(self.num_coordinates + 1, dtype = float)

        return
    
    # Function that would perform the machine learning using the perceptron algorithm
    def percepAlgo(self):
        
        while(self.currentIteration < 1000):
            # Create a table for the current iteration
            displayTable = PrettyTable(self.column_headers)
            displayTable.float_format = '.2'
            displayTable.border = False
            displayTable.align = 'l'
            displayTable.left_padding_width = 3

            # Reset the array containing the weights for each individual feature vector
            self.all_weights = []

            # Prepare the individual feature vectors
            for index, vector in enumerate(self.training_data):
                # Reference: https://www.geeksforgeeks.org/insert-an-element-at-specific-index-in-a-list-and-return-updated-list/
                
                # Initialize the vector as a numpy array that holds float values
                vector = np.array(vector, dtype = np.float64)

                # Insert the bias in the training data before the last column
                vector = np.insert(vector, self.num_coordinates, self.bias)

                # Insert the weight in the training data before the last column
                vector = np.insert(vector, self.num_coordinates + 1, self.weights)
                
                # Replace the current vector with the new vector
                self.training_data[index] = vector

                # Compute for the perceptron value, a
                a = 0.0
                a = np.dot(vector[:len(self.weights)], vector[len(self.weights):len(self.weights) * 2])
                
                # Determine the classification, y
                y = 1 if a > self.threshold else 0

                result = [a, y]
                
                # Insert the values of a and y to the individual feature vector
                vector = np.insert(vector, self.num_coordinates + 1 + len(self.weights), result)
                
                # Update the current vector with the new vector
                self.training_data[index] = vector
                
                # Add the final feature vector as a row to the current iteration's table
                displayTable.add_row(self.training_data[index])

                # Append the weight of this current row to the array holding all the weights of each vector in this table
                self.all_weights.append(vector[len(self.weights): len(self.weights) * 2])

                # Update the weights of the next feature vector
                for index in range(len(self.weights)):
                    self.weights[index] = self.weights[index] + (self.learning_rate * vector[index] * (vector[-1] - y))

            # Reset the individual feature vectors
            self.training_data = []
            self.read_input()

            # Write the table to the output file
            with open('output.txt', 'a') as f:
                f.write(f'Iteration {self.currentIteration}:\n')
                for row in displayTable.get_string().split("\n"):
                    f.write("\t " + row + "\n")
            
            # Check if the weights have converged
            self.all_weights.pop(0)
            if (all(np.array_equal(self.all_weights[i], self.weights) for i in range(len(self.all_weights)))):
                # If so, update the boolean flag for the checking if the weights were able to converge and break the loop
                self.hasConverge = True
                break
            
            # Otherwise, proceed to the next iteration
            self.currentIteration += 1

        # Checks if it has exhausted all 1000 iterations, which means that its weights are not converging
        # Hence, the data is not linearly separable
        if (self.hasConverge == False):
            with open('output.txt', 'w') as f:
                f.write('Not Converging!')

        return

# Clear the contents of the output file
open('output.txt', 'w').close()

# Create an instance of the Perceptron class
perceptron = Perceptron('input.txt')

# Initialize the first table
perceptron.initializePerceptron()

# Perform the machine learning using the perceptron algorithm
perceptron.percepAlgo()